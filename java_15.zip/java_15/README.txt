﻿README - JAVA



/*----------INSTALATION----------*/



Pré-requis :
	
	- avoir Java JRE 1.7 ou plus et une base de données.

	- pour compiler le code source avoir JDK 1.7 ou plus, une base de données et sqlconnector.jar ajouté
	en CLASSPATH de l'éditeur ou compiler avec commande javac Principale.java 
	et lancer avec java -cp sqlconnector.jar:. Principale en vous plaçant dans le dossier code source.

	- Créer une base de données.

	- Y installer le script SQL db.sql ou utiliser les boutons "Créer les tables" et après "Ajouter les questions par défaut" dans l'interface java
	dans l'onglet option, les tables et les questions seront installées dans la base sélectionnée lors de la connexion.



Exécution :
	
	- double-cliquer sur le burger_quizz.jar sous Windows et pour Linux lancer le jar avec la commande java -jar burger_quizz.jar

	- pour vous connecter à votre base l'url s'écrit de cette façon mysql://ADRESSE_DE_LA_BASE/LA_BASE
	et les 2 autres champs sont-ce du login et du mot de passe d'un utilisateur de votre base de données.



/*----------UTILISATION----------*/



Après la connexion, vous trouverez un onglet aide dans la barre d'outil, cliquez dessus et vous aurez toutes les explications
nécessaires pour l'utilisation de l'interface.

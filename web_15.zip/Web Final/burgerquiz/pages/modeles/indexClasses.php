<?php

/*--------------------------------------------------------------------------*/
/*------CE-FICHIER-REGROUPE-TOUTES-LES-CLASSES-UTILISSES-DANS-LE-PROJET-----*/
/*------------------------IL-EST-INCLUS-DANS-L'INDEX------------------------*/
/*--------------------------------------------------------------------------*/

	require_once('pages/modeles/categorie.class.php');
	require_once('pages/modeles/historique.class.php');
	require_once('pages/modeles/question.class.php');
	require_once('pages/modeles/sousquestion.class.php');
	require_once('pages/modeles/utilisateur.class.php');
	require_once('pages/modeles/temps.class.php');
	require_once('pages/modeles/partie.class.php');
	
?>
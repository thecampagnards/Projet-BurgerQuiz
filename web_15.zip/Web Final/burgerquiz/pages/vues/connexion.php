<!---------------------------------------------------->
<!-----------------PAGE-DE-CONNEXION------------------>
<!---------------------------------------------------->

<div class="container">
	<div class="titre"><h2>Connexion</h2></div>
	<form class="formulaire" id="connexion" method="post" action="index.php?page=compte&action=connexion">
		<input required placeholder="Pseudo" type="text" name="pseudo">
		<input required placeholder="Mot de passe" type="password" name="login">
		<input type="submit" value="Valider">
	</form>
</div>
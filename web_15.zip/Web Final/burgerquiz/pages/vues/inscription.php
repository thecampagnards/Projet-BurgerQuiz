<!---------------------------------------------------->
<!----------------PAGE-D'INSCRIPTION------------------>
<!---------------------------------------------------->

<div class="container">
	<div class="titre"><h2>Inscription</h2></div>
	<form class="formulaire" id="inscription" method="post" action="index.php?page=compte&action=inscription">
		<input required placeholder="Pseudo" type="text" name="pseudo">
		<input required placeholder="Mot de passe" type="password" name="login">
		<input type="submit" value="Valider">
	</form>
</div>
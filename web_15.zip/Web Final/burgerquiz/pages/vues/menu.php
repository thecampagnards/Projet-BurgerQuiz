<!---------------------------------------------------->
<!--------MENU-INCLUS-DANS-TOUTES-LES-PAGES----------->
<!---------------------------------------------------->

<nav>
	<ul>
		<li><a href="index.php"><span>Accueil</span><i class="icon-home"></i></a></li>
		<?php echo '<li>'.$sectionMenu2.'</li>'; ?>
		<li><a href="index.php?page=palmares"><span>Palmares</span><i class="icon-award"></i></a></li>
		<li><a href="index.php?page=regles"><span>Règles</span><i class="icon-doc-text"></i></a></li>
		<?php echo '<li>'.$sectionMenu4.'</li>'; ?>
	</ul>
</nav>